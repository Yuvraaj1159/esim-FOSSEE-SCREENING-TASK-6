# Report Examples

These three reports are generated from `board_fixture.json` and `config_fixture.json` using the current analyzer. The fixture is synthetic JSON, not a native KiCad board. It models a `CLK` route over a `GND` plane with a slot that produces a review finding, and declares the fixture's nets and four copper layers so the reports demonstrate the inventory section.

- `fixture_report.html`: readable report view.
- `fixture_report.json`: complete structured result, including board inventory, counts, and gap measurements.
- `fixture_report.csv`: one row per finding; nested measurements are JSON-encoded in their cells.

Expected result: `REVIEW`, 80% sampled coverage, and a 2.0 mm longest gap against a 0.5 mm configured limit. Inventory is complete for this synthetic fixture; real-board inventory completeness depends on which KiCad API methods are available.
