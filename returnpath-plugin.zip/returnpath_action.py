from __future__ import annotations

import json
import webbrowser
from pathlib import Path

from returnpath.analyzer import analyze_board
from returnpath.kicad_adapter import extract_board
from returnpath.report import write_csv_report, write_json_report, write_report


DEFAULT_CONFIG = {"version": 1, "nets": {}}


def _project_directory(kicad, board) -> Path:
    document = getattr(board, "document", None)
    if document is not None:
        try:
            project_path = Path(str(kicad.get_project(document).path))
            if project_path.suffix.lower() in {".kicad_pro", ".pro"}:
                return project_path.parent
            if str(project_path) not in ("", "."):
                return project_path
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass

        board_path = getattr(document, "board_filename", None)
        if board_path:
            board_path = Path(str(board_path))
            return board_path.parent if board_path.suffix else board_path
    return Path.cwd()


def _open_report(path: Path) -> None:
    try:
        webbrowser.open(path.resolve().as_uri())
    except Exception as error:
        print(f"Return-Path Analyzer wrote report to {path}: {error}")


def main() -> None:
    try:
        from kipy import KiCad
    except ImportError as error:
        raise RuntimeError("KiCad's managed plugin environment is missing kicad-python. Restart KiCad and check the plugin environment log.") from error

    kicad = KiCad()
    board = kicad.get_board()
    if board is None:
        raise RuntimeError("No PCB is open in the KiCad PCB Editor.")

    project_dir = _project_directory(kicad, board)
    config_path = project_dir / "returnpath_config.json"
    report_path = project_dir / "returnpath_report.html"
    json_path = project_dir / "returnpath_report.json"
    csv_path = project_dir / "returnpath_report.csv"
    if not config_path.exists():
        config_path.write_text(json.dumps(DEFAULT_CONFIG, indent=2), encoding="utf-8")
        result = {
            "board_name": getattr(getattr(board, "document", None), "board_filename", "KiCad board"),
            "overall_status": "NOT_EVALUATED",
            "finding_count": 1,
            "counts": {"REVIEW": 0, "WITHIN_USER_LIMITS": 0, "NOT_EVALUATED": 1},
            "findings": [{
                "kind": "CONFIGURATION",
                "status": "NOT_EVALUATED",
                "net": "",
                "message": "Configuration is missing; add signal nets and reference mappings, then run again.",
            }],
        }
        note = f"Configuration created at {config_path}. Add signal net names and reference-layer mappings, save the file, then run the add-on again."
        write_report(report_path, result, note)
        write_json_report(json_path, result, note)
        write_csv_report(csv_path, result, note)
        _open_report(report_path)
        return

    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeError(f"Could not read {config_path}: {error}") from error
    if not isinstance(config, dict) or not isinstance(config.get("nets"), dict):
        raise RuntimeError("Configuration must be an object with a 'nets' object.")
    if config.get("version") != 1:
        raise RuntimeError("Unsupported configuration version. Set 'version' to 1.")
    for net, settings in config["nets"].items():
        if not isinstance(net, str) or not net.strip() or not isinstance(settings, dict):
            raise RuntimeError("Each configured net must have a non-empty name and an object of settings.")
        mappings = settings.get("reference_by_signal_layer", {})
        if not isinstance(mappings, dict) or any(not isinstance(mapping, dict) for mapping in mappings.values()):
            raise RuntimeError(f"Reference mappings for {net!r} must be an object of layer objects.")

    board_data = extract_board(board)
    result = analyze_board(board_data, config)
    write_report(report_path, result)
    write_json_report(json_path, result)
    write_csv_report(csv_path, result)
    _open_report(report_path)
    print(f"Return-Path Analyzer report: {report_path}")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"Return-Path Analyzer could not run: {error}")
        raise
