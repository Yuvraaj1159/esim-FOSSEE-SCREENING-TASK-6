from pathlib import Path
import unittest
from types import SimpleNamespace

from returnpath_action import _project_directory


class ActionHelperTests(unittest.TestCase):
    def test_project_file_resolves_to_its_folder(self):
        document = object()
        kicad = SimpleNamespace(
            get_project=lambda _: SimpleNamespace(path="/designs/demo/demo.kicad_pro")
        )
        board = SimpleNamespace(document=document)
        self.assertEqual(_project_directory(kicad, board), Path("/designs/demo"))

    def test_board_filename_is_fallback_when_project_is_unavailable(self):
        document = SimpleNamespace(board_filename="/designs/demo/demo.kicad_pcb")
        kicad = SimpleNamespace(get_project=lambda _: None)
        board = SimpleNamespace(document=document)
        self.assertEqual(_project_directory(kicad, board), Path("/designs/demo"))


if __name__ == "__main__":
    unittest.main()
