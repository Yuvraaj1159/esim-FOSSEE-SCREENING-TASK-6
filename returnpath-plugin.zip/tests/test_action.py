from pathlib import Path
import unittest
from types import SimpleNamespace

from returnpath_action import _error_result, _project_directory, _validate_config


class ActionHelperTests(unittest.TestCase):
    def test_project_file_resolves_to_its_folder(self):
        document = object()
        kicad = SimpleNamespace(
            get_project=lambda _: SimpleNamespace(path="/designs/demo/demo.kicad_pro")
        )
        board = SimpleNamespace(document=document)
        self.assertEqual(_project_directory(kicad, board), Path("/designs/demo"))

    def test_board_filename_is_fallback_when_project_is_unavailable(self):
        document = SimpleNamespace(board_filename="/designs/demo/demo.kicad_pcb")
        kicad = SimpleNamespace(get_project=lambda _: None)
        board = SimpleNamespace(document=document)
        self.assertEqual(_project_directory(kicad, board), Path("/designs/demo"))

    def test_structural_config_errors_can_be_serialized_for_the_report(self):
        with self.assertRaisesRegex(ValueError, "'nets' object"):
            _validate_config({"version": 1, "nets": []})

        result = _error_result("fixture.kicad_pcb", ValueError("bad config"))
        self.assertEqual(result["overall_status"], "NOT_EVALUATED")
        self.assertIn("bad config", result["findings"][0]["message"])


if __name__ == "__main__":
    unittest.main()
