import json
from pathlib import Path
import unittest

from returnpath.analyzer import analyze_board


MM = 1_000_000


def board_with_plane(slot=False):
    hole = [[(4 * MM, -400_000), (6 * MM, -400_000), (6 * MM, 400_000), (4 * MM, 400_000)]] if slot else []
    return {
        "board_name": "test-board",
        "zone_geometry_available": True,
        "tracks": [
            {"id": "clk-1", "net": "CLK", "layer": "F.Cu", "width_nm": 200_000, "points": [(0, 0), (10 * MM, 0)]}
        ],
        "vias": [],
        "zones": [
            {"net": "GND", "layer": "In1.Cu", "filled": True, "polygons": [{"outer": [(-MM, -MM), (11 * MM, -MM), (11 * MM, MM), (-MM, MM)], "holes": hole}]}
        ],
        "unfilled_zones": [],
        "unsupported_zones": [],
    }


def config():
    return {
        "version": 1,
        "nets": {
            "CLK": {
                "reference_by_signal_layer": {
                    "F.Cu": {"net": "GND", "layer": "In1.Cu"},
                    "In2.Cu": {"net": "GND", "layer": "In3.Cu"},
                },
                "corridor_width_mm": 0.6,
                "sample_pitch_mm": 0.25,
                "samples_across": 5,
                "min_coverage": 0.8,
                "max_gap_mm": 0.5,
                "max_return_via_offset_mm": 1.0,
                "via_match_tolerance_mm": 0.1,
            }
        },
    }


class AnalyzerTests(unittest.TestCase):
    def test_json_fixture_reports_the_plane_slot(self):
        examples = Path(__file__).resolve().parents[1] / "examples"
        board = json.loads((examples / "board_fixture.json").read_text(encoding="utf-8"))
        settings = json.loads((examples / "config_fixture.json").read_text(encoding="utf-8"))
        result = analyze_board(board, settings)
        coverage = next(f for f in result["findings"] if f["kind"] == "REFERENCE_COVERAGE")
        self.assertEqual(coverage["status"], "REVIEW")
        self.assertGreater(coverage["longest_gap_mm"], 0.5)

    def test_continuous_reference_is_within_configured_limits(self):
        result = analyze_board(board_with_plane(), config())
        coverage = next(f for f in result["findings"] if f["kind"] == "REFERENCE_COVERAGE")
        self.assertEqual(coverage["status"], "WITHIN_USER_LIMITS")
        self.assertEqual(coverage["coverage_percent"], 100.0)

    def test_plane_slot_creates_review_gap(self):
        result = analyze_board(board_with_plane(slot=True), config())
        coverage = next(f for f in result["findings"] if f["kind"] == "REFERENCE_COVERAGE")
        self.assertEqual(coverage["status"], "REVIEW")
        self.assertGreater(coverage["longest_gap_mm"], 0.5)

    def test_missing_zone_geometry_fails_closed(self):
        board = board_with_plane()
        board["zone_geometry_available"] = False
        result = analyze_board(board, config())
        coverage = next(f for f in result["findings"] if f["kind"] == "REFERENCE_COVERAGE")
        self.assertEqual(coverage["status"], "NOT_EVALUATED")

    def test_missing_reference_mapping_fails_closed(self):
        settings = config()
        settings["nets"]["CLK"]["reference_by_signal_layer"] = {}
        result = analyze_board(board_with_plane(), settings)
        coverage = next(f for f in result["findings"] if f["kind"] == "REFERENCE_COVERAGE")
        self.assertEqual(coverage["status"], "NOT_EVALUATED")

    def test_reference_via_spanning_both_planes_is_detected(self):
        board = board_with_plane()
        board["tracks"].extend([
            {"id": "clk-2", "net": "CLK", "layer": "In2.Cu", "width_nm": 200_000, "points": [(5 * MM, 0), (10 * MM, 0)]}
        ])
        board["vias"] = [
            {"id": "signal-via", "net": "CLK", "position": (5 * MM, 0), "diameter_nm": 600_000, "layers": ["F.Cu", "In2.Cu"]},
            {"id": "return-via", "net": "GND", "position": (5_500_000, 0), "diameter_nm": 600_000, "layers": ["In1.Cu", "In3.Cu"]},
        ]
        board["zones"].append({"net": "GND", "layer": "In3.Cu", "filled": True, "polygons": [{"outer": [(-MM, -MM), (11 * MM, -MM), (11 * MM, MM), (-MM, MM)], "holes": []}]})
        result = analyze_board(board, config())
        transition = next(f for f in result["findings"] if f["kind"] == "RETURN_VIA")
        self.assertEqual(transition["status"], "WITHIN_USER_LIMITS")
        self.assertEqual(transition["offset_mm"], 0.5)

    def test_nearby_via_on_wrong_net_does_not_satisfy_transition(self):
        board = board_with_plane()
        board["tracks"].append({"id": "clk-2", "net": "CLK", "layer": "In2.Cu", "width_nm": 200_000, "points": [(5 * MM, 0), (10 * MM, 0)]})
        board["vias"] = [
            {"id": "signal-via", "net": "CLK", "position": (5 * MM, 0), "diameter_nm": 600_000, "layers": ["F.Cu", "In2.Cu"]},
            {"id": "wrong-via", "net": "SHIELD", "position": (5_100_000, 0), "diameter_nm": 600_000, "layers": ["In1.Cu", "In3.Cu"]},
        ]
        board["zones"].append({"net": "GND", "layer": "In3.Cu", "filled": True, "polygons": [{"outer": [(-MM, -MM), (11 * MM, -MM), (11 * MM, MM), (-MM, MM)], "holes": []}]})
        result = analyze_board(board, config())
        transition = next(f for f in result["findings"] if f["kind"] == "RETURN_VIA")
        self.assertEqual(transition["status"], "REVIEW")
        self.assertIsNone(transition["offset_mm"])


if __name__ == "__main__":
    unittest.main()
