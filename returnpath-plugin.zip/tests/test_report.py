import csv
import json
import tempfile
import unittest
from pathlib import Path

from returnpath.report import render_report, write_csv_report, write_json_report


class ReportExportTests(unittest.TestCase):
    def test_html_report_lists_board_inventory_safely(self):
        result = {
            "board_name": "fixture",
            "overall_status": "NOT_EVALUATED",
            "counts": {"REVIEW": 0, "WITHIN_USER_LIMITS": 0, "NOT_EVALUATED": 1},
            "findings": [],
            "board_inventory": {
                "nets": ["CLK", "<script>"],
                "net_inventory_complete": True,
                "copper_layers": ["F.Cu", "In1.Cu"],
                "layer_inventory_complete": False,
            },
        }

        html = render_report(result)

        self.assertIn("Board inventory", html)
        self.assertIn("CLK, &lt;script&gt;", html)
        self.assertIn("observed items only", html)

    def test_json_and_csv_exports_keep_nested_measurements(self):
        result = {
            "board_name": "fixture",
            "overall_status": "REVIEW",
            "finding_count": 1,
            "counts": {"REVIEW": 1, "WITHIN_USER_LIMITS": 0, "NOT_EVALUATED": 0},
            "findings": [{
                "kind": "REFERENCE_COVERAGE",
                "status": "REVIEW",
                "net": "CLK",
                "message": "gap, near slot",
                "gaps": [{"start_mm": 4.0, "end_mm": 6.0, "length_mm": 2.0}],
            }],
        }
        with tempfile.TemporaryDirectory() as temp_dir:
            json_path = write_json_report(Path(temp_dir) / "report.json", result, "synthetic fixture")
            csv_path = write_csv_report(Path(temp_dir) / "report.csv", result, "synthetic fixture")

            payload = json.loads(json_path.read_text(encoding="utf-8"))
            with csv_path.open(newline="", encoding="utf-8") as source:
                row = next(csv.DictReader(source))

        self.assertEqual(payload["note"], "synthetic fixture")
        self.assertEqual(payload["findings"][0]["gaps"][0]["length_mm"], 2.0)
        self.assertEqual(row["message"], "gap, near slot")
        self.assertEqual(json.loads(row["gaps"])[0]["length_mm"], 2.0)
        self.assertEqual(row["note"], "synthetic fixture")


if __name__ == "__main__":
    unittest.main()
