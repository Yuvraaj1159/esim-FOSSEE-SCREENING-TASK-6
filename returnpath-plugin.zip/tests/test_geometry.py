import unittest

from returnpath.geometry import arc_to_polyline, distance_to_segment, point_in_polygon, polyline_cells


class GeometryTests(unittest.TestCase):
    def test_polygon_hole_is_not_copper(self):
        polygon = {
            "outer": [(0, 0), (10, 0), (10, 10), (0, 10)],
            "holes": [[(4, 4), (6, 4), (6, 6), (4, 6)]],
        }
        self.assertTrue(point_in_polygon((2, 2), polygon))
        self.assertFalse(point_in_polygon((5, 5), polygon))

    def test_distance_to_segment_clamps_to_endpoints(self):
        self.assertAlmostEqual(distance_to_segment((12, 5), (0, 0), (10, 0)), (29) ** 0.5)

    def test_arc_approximation_preserves_endpoints_and_radius(self):
        points = arc_to_polyline((1_000_000, 0), (0, 1_000_000), (-1_000_000, 0), 10_000)
        self.assertEqual(points[0], (1_000_000, 0))
        self.assertEqual(points[-1], (-1_000_000, 0))
        for x, y in points:
            self.assertAlmostEqual((x * x + y * y) ** 0.5, 1_000_000, delta=10_000)

    def test_polyline_cells_cover_path_length(self):
        cells = list(polyline_cells([(0, 0), (7, 0), (7, 5)], 4))
        self.assertAlmostEqual(sum(cell[1] for cell in cells), 12)
        self.assertEqual(len(cells), 3)


if __name__ == "__main__":
    unittest.main()
