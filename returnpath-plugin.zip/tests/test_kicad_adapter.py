import unittest
from types import SimpleNamespace

from returnpath.kicad_adapter import _layer_name, extract_board


def polyline(points):
    return SimpleNamespace(
        nodes=[
            SimpleNamespace(has_arc=False, has_point=True, point=SimpleNamespace(x=x, y=y))
            for x, y in points
        ]
    )


class FakeBoard:
    def __init__(self, zone):
        track = SimpleNamespace(
            id="track-1",
            net=SimpleNamespace(name="CLK"),
            layer="F.Cu",
            width=200_000,
            start=SimpleNamespace(x=0, y=0),
            end=SimpleNamespace(x=10_000_000, y=0),
        )
        self.document = SimpleNamespace(board_filename="fixture.kicad_pcb")
        self._tracks = [track]
        self._vias = []
        self._zones = [zone]

    def get_tracks(self):
        return self._tracks

    def get_vias(self):
        return self._vias

    def get_zones(self):
        return self._zones

    def get_nets(self):
        return {"CLK": SimpleNamespace(name="CLK"), "GND": SimpleNamespace(name="GND")}

    def get_enabled_layers(self):
        return ["F.Cu", "In1.Cu", "In2.Cu", "In3.Cu"]

    def get_layer_name(self, layer):
        return {0: "F_Cu", 1: "In1_Cu"}.get(layer)


class AdapterTests(unittest.TestCase):
    def test_extracts_track_and_filled_polygon_hole(self):
        polygon = SimpleNamespace(
            outline=polyline([(0, 0), (10_000_000, 0), (10_000_000, 1_000_000)]),
            holes=[polyline([(4_000_000, 0), (6_000_000, 0), (6_000_000, 500_000)])],
        )
        zone = SimpleNamespace(
            net=SimpleNamespace(name="GND"),
            is_rule_area=False,
            filled=True,
            filled_polygons={"In1.Cu": [polygon]},
        )
        board = extract_board(FakeBoard(zone))
        self.assertTrue(board["zone_geometry_available"])
        self.assertEqual(board["tracks"][0]["points"], [(0, 0), (10_000_000, 0)])
        self.assertEqual(board["zones"][0]["polygons"][0]["holes"][0][0], (4_000_000, 0))

    def test_arc_in_filled_zone_is_reported_as_unsupported(self):
        outline = polyline([(0, 0), (10_000_000, 0), (10_000_000, 1_000_000)])
        outline.nodes[1].has_arc = True
        zone = SimpleNamespace(
            net=SimpleNamespace(name="GND"),
            is_rule_area=False,
            filled=True,
            filled_polygons={"In1.Cu": [SimpleNamespace(outline=outline, holes=[])]},
        )
        board = extract_board(FakeBoard(zone))
        self.assertTrue(board["zone_geometry_available"])
        self.assertEqual(board["unsupported_zones"], [{"net": "GND", "layer": "In1.Cu"}])
        self.assertEqual(board["zones"], [])

    def test_integer_layers_and_canonical_enum_names_match_config_names(self):
        polygon = SimpleNamespace(outline=polyline([(0, 0), (10_000_000, 0), (10_000_000, 1_000_000)]), holes=[])
        zone = SimpleNamespace(
            net=SimpleNamespace(name="GND"),
            is_rule_area=False,
            filled=True,
            filled_polygons={1: [polygon]},
        )
        board = FakeBoard(zone)
        board._tracks[0].layer = 0

        extracted = extract_board(board)

        self.assertEqual(extracted["tracks"][0]["layer"], "F.Cu")
        self.assertEqual(extracted["zones"][0]["layer"], "In1.Cu")
        self.assertEqual(extracted["copper_layers"], ["F.Cu", "In1.Cu", "In2.Cu", "In3.Cu"])
        self.assertTrue(extracted["layer_inventory_complete"])
        self.assertTrue(extracted["net_inventory_complete"])
        self.assertEqual(_layer_name(SimpleNamespace(canonical_name="BL_F_Cu")), "F.Cu")
        self.assertEqual(_layer_name(SimpleNamespace(name="BL_In1_Cu")), "In1.Cu")

    def test_via_size_fallback_is_extracted_instead_of_silently_zero(self):
        zone = SimpleNamespace(net=SimpleNamespace(name="GND"), is_rule_area=False, filled=False, layers=[])
        board = FakeBoard(zone)
        board._vias = [SimpleNamespace(
            id="via-1",
            net=SimpleNamespace(name="GND"),
            position=SimpleNamespace(x=100, y=200),
            size=600_000,
            padstack=SimpleNamespace(layers=[0, 1]),
        )]

        extracted = extract_board(board)

        self.assertEqual(extracted["vias"][0]["diameter_nm"], 600_000)
        self.assertEqual(extracted["vias"][0]["layers"], ["F.Cu", "In1.Cu"])

    def test_via_without_a_readable_size_fails_instead_of_becoming_zero(self):
        zone = SimpleNamespace(net=SimpleNamespace(name="GND"), is_rule_area=False, filled=False, layers=[])
        board = FakeBoard(zone)
        board._vias = [SimpleNamespace(
            id="via-1",
            net=SimpleNamespace(name="GND"),
            position=SimpleNamespace(x=100, y=200),
            padstack=SimpleNamespace(layers=[0, 1]),
        )]

        with self.assertRaisesRegex(ValueError, "no readable diameter or size"):
            extract_board(board)


if __name__ == "__main__":
    unittest.main()
