import unittest
from types import SimpleNamespace

from returnpath.kicad_adapter import extract_board


def polyline(points):
    return SimpleNamespace(
        nodes=[
            SimpleNamespace(has_arc=False, has_point=True, point=SimpleNamespace(x=x, y=y))
            for x, y in points
        ]
    )


class FakeBoard:
    def __init__(self, zone):
        track = SimpleNamespace(
            id="track-1",
            net=SimpleNamespace(name="CLK"),
            layer="F.Cu",
            width=200_000,
            start=SimpleNamespace(x=0, y=0),
            end=SimpleNamespace(x=10_000_000, y=0),
        )
        self.document = SimpleNamespace(board_filename="fixture.kicad_pcb")
        self._tracks = [track]
        self._zones = [zone]

    def get_tracks(self):
        return self._tracks

    def get_vias(self):
        return []

    def get_zones(self):
        return self._zones


class AdapterTests(unittest.TestCase):
    def test_extracts_track_and_filled_polygon_hole(self):
        polygon = SimpleNamespace(
            outline=polyline([(0, 0), (10_000_000, 0), (10_000_000, 1_000_000)]),
            holes=[polyline([(4_000_000, 0), (6_000_000, 0), (6_000_000, 500_000)])],
        )
        zone = SimpleNamespace(
            net=SimpleNamespace(name="GND"),
            is_rule_area=False,
            filled=True,
            filled_polygons={"In1.Cu": [polygon]},
        )
        board = extract_board(FakeBoard(zone))
        self.assertTrue(board["zone_geometry_available"])
        self.assertEqual(board["tracks"][0]["points"], [(0, 0), (10_000_000, 0)])
        self.assertEqual(board["zones"][0]["polygons"][0]["holes"][0][0], (4_000_000, 0))

    def test_arc_in_filled_zone_is_reported_as_unsupported(self):
        outline = polyline([(0, 0), (10_000_000, 0), (10_000_000, 1_000_000)])
        outline.nodes[1].has_arc = True
        zone = SimpleNamespace(
            net=SimpleNamespace(name="GND"),
            is_rule_area=False,
            filled=True,
            filled_polygons={"In1.Cu": [SimpleNamespace(outline=outline, holes=[])]},
        )
        board = extract_board(FakeBoard(zone))
        self.assertTrue(board["zone_geometry_available"])
        self.assertEqual(board["unsupported_zones"], [{"net": "GND", "layer": "In1.Cu"}])
        self.assertEqual(board["zones"], [])


if __name__ == "__main__":
    unittest.main()
