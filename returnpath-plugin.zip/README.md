# Return-Path Continuity Analyzer

A read-only KiCad PCB Editor add-on prototype that reviews configured signal nets for local reference-copper coverage gaps and return-via proximity at layer transitions. It writes HTML, JSON, and CSV reports.

## Package Contents

- `plugin.json`: KiCad IPC API action metadata.
- `returnpath_action.py`: add-on entry point; writes a JSON configuration template and HTML, JSON, and CSV reports beside the project.
- `returnpath/`: geometry extraction, analysis, and report generation.
- `returnpath_config.example.json`: starting point for board-specific net/layer mappings.
- `examples/`: synthetic board and configuration fixtures plus expected HTML, JSON, and CSV report examples. The board fixture is JSON, not a native `.kicad_pcb` file.
- `tests/`: standard-library unit tests for geometry and analysis behavior.
- `DESIGN.html` and `DESIGN.pdf`: formatted design note in Times New Roman.
- `INSTALL_TEST.md`: installation and manual verification instructions.

## Quick Test

From this folder, run:

```text
python -m unittest discover -s tests -v
```

The tests do not require KiCad. They exercise the analysis core with synthetic geometry and API-shaped layer/via test doubles; they do not verify KiCad IPC integration. Config and extraction failures after a board opens are written to the generated `NOT_EVALUATED` report where possible.

## Important Scope

The analyzer measures sampled, local geometry. It does not calculate electromagnetic fields, signal integrity, return-current distribution, or global copper connectivity. Treat findings as engineering review prompts, not certification or a replacement for KiCad DRC or a field solver. See `DESIGN.html` for method and limitations.
