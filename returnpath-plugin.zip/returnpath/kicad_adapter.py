from __future__ import annotations

from .geometry import arc_to_polyline


class UnsupportedZoneGeometry(Exception):
    pass


def _value(obj, name, default=None):
    result = getattr(obj, name, default)
    return result() if callable(result) else result


def _normalize_layer_name(name) -> str:
    name = str(name)
    if name.startswith("BL_"):
        name = name[3:]
    if name in ("F_Cu", "F_CU", "F.Cu"):
        return "F.Cu"
    if name in ("B_Cu", "B_CU", "B.Cu"):
        return "B.Cu"
    if name.startswith("In") and ("_Cu" in name or ".Cu" in name):
        return name.replace("_Cu", ".Cu")
    return name


def _point(value) -> tuple[int, int]:
    x = getattr(value, "x", getattr(value, "x_nm", None))
    y = getattr(value, "y", getattr(value, "y_nm", None))
    if x is None or y is None:
        raise ValueError("KiCad point has no x/y coordinates")
    return int(round(float(x))), int(round(float(y)))


def _layer_name(value, board=None) -> str:
    if isinstance(value, str):
        return _normalize_layer_name(value)

    canonical_name = _value(value, "canonical_name")
    if canonical_name:
        return _normalize_layer_name(canonical_name)

    get_layer_name = getattr(board, "get_layer_name", None)
    if callable(get_layer_name):
        try:
            name = get_layer_name(value)
        except (TypeError, ValueError, RuntimeError):
            name = None
        if name:
            return _normalize_layer_name(name)

    try:
        from kipy.board_types import BoardLayer

        layer = BoardLayer(int(value))
        canonical_name = _value(layer, "canonical_name")
        name = canonical_name or _value(layer, "name")
        if name:
            return _normalize_layer_name(name)
    except (ImportError, ValueError, TypeError):
        pass

    name = _value(value, "name")
    return _normalize_layer_name(name if name else value)


def _iter_values(value):
    if value is None:
        return ()
    if isinstance(value, dict):
        return value.values()
    if isinstance(value, (str, bytes)):
        return (value,)
    try:
        return iter(value)
    except TypeError:
        return (value,)


def _board_inventory(board, tracks, vias, zones, unfilled_zones, unsupported_zones):
    nets = set()
    net_inventory_complete = False
    get_nets = getattr(board, "get_nets", None)
    if callable(get_nets):
        try:
            for net in _iter_values(get_nets()):
                name = str(_value(net, "name", net))
                if name:
                    nets.add(name)
            net_inventory_complete = True
        except (RuntimeError, TypeError, ValueError):
            pass

    for item in (*tracks, *vias):
        name = _net_name(item)
        if name:
            nets.add(name)
    nets.update(zone["net"] for zone in zones + unfilled_zones + unsupported_zones if zone["net"])

    layers = set()
    layer_inventory_complete = False
    for method_name in ("get_enabled_layers", "get_copper_layers"):
        get_layers = getattr(board, method_name, None)
        if not callable(get_layers):
            continue
        try:
            raw_layers = get_layers()
            if isinstance(raw_layers, int):
                raw_layers = (index for index in range(32) if raw_layers & (1 << index))
            for layer in _iter_values(raw_layers):
                name = _layer_name(layer, board)
                if name.endswith(".Cu"):
                    layers.add(name)
            layer_inventory_complete = True
            break
        except (RuntimeError, TypeError, ValueError):
            continue

    for item in tracks:
        name = _layer_name(_value(item, "layer"), board)
        if name.endswith(".Cu"):
            layers.add(name)
    for item in vias:
        padstack = _value(item, "padstack")
        via_layers = _value(padstack, "layers")
        if via_layers is None:
            via_layers = _value(item, "layers", ())
        for layer in _iter_values(via_layers):
            name = _layer_name(layer, board)
            if name.endswith(".Cu"):
                layers.add(name)
    for zone in zones + unfilled_zones + unsupported_zones:
        if zone["layer"].endswith(".Cu"):
            layers.add(zone["layer"])

    return {
        "nets": sorted(nets),
        "net_inventory_complete": net_inventory_complete,
        "copper_layers": sorted(layers),
        "layer_inventory_complete": layer_inventory_complete,
    }


def _net_name(item) -> str:
    net = _value(item, "net")
    if net is None:
        return ""
    return str(_value(net, "name", net))


def _polyline_points(polyline) -> list[tuple[int, int]]:
    points = []
    for node in _value(polyline, "nodes", ()):
        if _value(node, "has_arc", False):
            raise UnsupportedZoneGeometry("arc in filled-zone polygon")
        if _value(node, "has_point", True):
            points.append(_point(_value(node, "point")))
    if len(points) > 1 and points[0] == points[-1]:
        points.pop()
    return points


def _polygon_record(polygon) -> dict:
    outer = _polyline_points(_value(polygon, "outline"))
    holes = [_polyline_points(hole) for hole in _value(polygon, "holes", ())]
    return {"outer": outer, "holes": holes}


def extract_board(board, chord_error_nm: int = 50_000) -> dict:
    tracks = []
    for index, item in enumerate(board.get_tracks()):
        start = _point(_value(item, "start"))
        end = _point(_value(item, "end"))
        layer = _value(item, "layer")
        width = _value(item, "width")
        if layer is None or width is None:
            raise ValueError("KiCad track is missing its layer or width")
        mid = _value(item, "mid") if hasattr(item, "mid") else None
        if mid is not None:
            points = arc_to_polyline(start, _point(mid), end, chord_error_nm)
        else:
            points = [start, end]
        tracks.append({
            "id": str(_value(item, "id", index)),
            "net": _net_name(item),
            "layer": _layer_name(layer, board),
            "width_nm": int(width),
            "points": points,
        })

    vias = []
    for index, item in enumerate(board.get_vias()):
        padstack = _value(item, "padstack")
        via_layers = _value(padstack, "layers")
        if via_layers is None:
            via_layers = _value(item, "layers", ())
        layers = [_layer_name(layer, board) for layer in via_layers]
        diameter = _value(item, "diameter")
        if diameter is None:
            diameter = _value(item, "size")
        if diameter is None:
            diameter = _value(padstack, "diameter")
        if diameter is None:
            diameter = _value(padstack, "size")
        if diameter is None:
            raise ValueError("KiCad via has no readable diameter or size")
        vias.append({
            "id": str(_value(item, "id", index)),
            "net": _net_name(item),
            "position": _point(_value(item, "position")),
            "diameter_nm": int(diameter),
            "layers": layers,
        })

    zones = []
    unfilled_zones = []
    unsupported_zones = []
    zone_geometry_available = True
    try:
        board_zones = board.get_zones()
    except (AttributeError, RuntimeError):
        board_zones = ()
        zone_geometry_available = False

    for item in board_zones:
        try:
            is_rule = _value(item, "is_rule_area", False)
            if is_rule:
                continue
            net = _net_name(item)
            filled = bool(_value(item, "filled", False))
            if not filled:
                for layer in _value(item, "layers", ()):
                    unfilled_zones.append({"net": net, "layer": _layer_name(layer, board)})
                continue
            filled_polygons = _value(item, "filled_polygons")
            for layer, polygons in filled_polygons.items():
                layer_name = _layer_name(layer, board)
                try:
                    polygon_records = [_polygon_record(polygon) for polygon in polygons]
                except (AttributeError, TypeError, ValueError, UnsupportedZoneGeometry):
                    unsupported_zones.append({"net": net, "layer": layer_name})
                    continue
                zones.append({"net": net, "layer": layer_name, "filled": True, "polygons": polygon_records})
        except (AttributeError, KeyError, RuntimeError, TypeError, ValueError):
            zone_geometry_available = False

    document = _value(board, "document")
    board_name = str(_value(document, "board_filename", "KiCad board")) if document else "KiCad board"
    result = {
        "board_name": board_name,
        "tracks": tracks,
        "vias": vias,
        "zones": zones,
        "unfilled_zones": unfilled_zones,
        "unsupported_zones": unsupported_zones,
        "zone_geometry_available": zone_geometry_available,
    }
    result.update(_board_inventory(board, tracks, vias, zones, unfilled_zones, unsupported_zones))
    return result
