from __future__ import annotations

from .geometry import arc_to_polyline


class UnsupportedZoneGeometry(Exception):
    pass


def _value(obj, name, default=None):
    result = getattr(obj, name, default)
    return result() if callable(result) else result


def _point(value) -> tuple[int, int]:
    x = getattr(value, "x", getattr(value, "x_nm", None))
    y = getattr(value, "y", getattr(value, "y_nm", None))
    if x is None or y is None:
        raise ValueError("KiCad point has no x/y coordinates")
    return int(round(float(x))), int(round(float(y)))


def _layer_name(value) -> str:
    if isinstance(value, str):
        return value
    name = getattr(value, "name", None)
    if not name:
        try:
            from kipy.board_types import BoardLayer

            name = BoardLayer(int(value)).name
        except (ImportError, ValueError, TypeError):
            return str(value)
    name = str(name)
    if name in ("F_Cu", "F_CU"):
        return "F.Cu"
    if name in ("B_Cu", "B_CU"):
        return "B.Cu"
    if name.startswith("In") and "_Cu" in name:
        return name.replace("_Cu", ".Cu")
    return name


def _net_name(item) -> str:
    net = _value(item, "net")
    if net is None:
        return ""
    return str(_value(net, "name", net))


def _polyline_points(polyline) -> list[tuple[int, int]]:
    points = []
    for node in _value(polyline, "nodes", ()):
        if _value(node, "has_arc", False):
            raise UnsupportedZoneGeometry("arc in filled-zone polygon")
        if _value(node, "has_point", True):
            points.append(_point(_value(node, "point")))
    if len(points) > 1 and points[0] == points[-1]:
        points.pop()
    return points


def _polygon_record(polygon) -> dict:
    outer = _polyline_points(_value(polygon, "outline"))
    holes = [_polyline_points(hole) for hole in _value(polygon, "holes", ())]
    return {"outer": outer, "holes": holes}


def extract_board(board, chord_error_nm: int = 50_000) -> dict:
    tracks = []
    for index, item in enumerate(board.get_tracks()):
        start = _point(_value(item, "start"))
        end = _point(_value(item, "end"))
        if hasattr(item, "mid"):
            points = arc_to_polyline(start, _point(_value(item, "mid")), end, chord_error_nm)
        else:
            points = [start, end]
        tracks.append({
            "id": str(_value(item, "id", index)),
            "net": _net_name(item),
            "layer": _layer_name(_value(item, "layer")),
            "width_nm": int(_value(item, "width", 0)),
            "points": points,
        })

    vias = []
    for index, item in enumerate(board.get_vias()):
        padstack = _value(item, "padstack")
        layers = [_layer_name(layer) for layer in _value(padstack, "layers", ())]
        vias.append({
            "id": str(_value(item, "id", index)),
            "net": _net_name(item),
            "position": _point(_value(item, "position")),
            "diameter_nm": int(_value(item, "diameter", 0)),
            "layers": layers,
        })

    zones = []
    unfilled_zones = []
    unsupported_zones = []
    zone_geometry_available = True
    try:
        board_zones = board.get_zones()
    except (AttributeError, RuntimeError):
        board_zones = ()
        zone_geometry_available = False

    for item in board_zones:
        try:
            is_rule = _value(item, "is_rule_area", False)
            if is_rule:
                continue
            net = _net_name(item)
            filled = bool(_value(item, "filled", False))
            if not filled:
                for layer in _value(item, "layers", ()):
                    unfilled_zones.append({"net": net, "layer": _layer_name(layer)})
                continue
            filled_polygons = _value(item, "filled_polygons")
            for layer, polygons in filled_polygons.items():
                layer_name = _layer_name(layer)
                try:
                    polygon_records = [_polygon_record(polygon) for polygon in polygons]
                except (AttributeError, TypeError, ValueError, UnsupportedZoneGeometry):
                    unsupported_zones.append({"net": net, "layer": layer_name})
                    continue
                zones.append({"net": net, "layer": layer_name, "filled": True, "polygons": polygon_records})
        except (AttributeError, KeyError, RuntimeError, TypeError, ValueError):
            zone_geometry_available = False

    document = _value(board, "document")
    board_name = str(_value(document, "board_filename", "KiCad board")) if document else "KiCad board"
    return {
        "board_name": board_name,
        "tracks": tracks,
        "vias": vias,
        "zones": zones,
        "unfilled_zones": unfilled_zones,
        "unsupported_zones": unsupported_zones,
        "zone_geometry_available": zone_geometry_available,
    }
