from __future__ import annotations

from itertools import combinations
from math import hypot
from typing import Iterable

from .geometry import distance_to_segment, point_in_polygon, polyline_cells

CONFIG_KEYS = {"version", "nets"}
SETTING_KEYS = {
    "reference_by_signal_layer",
    "corridor_width_mm",
    "sample_pitch_mm",
    "samples_across",
    "min_coverage",
    "max_gap_mm",
    "max_return_via_offset_mm",
    "via_match_tolerance_mm",
}


def _mm_to_nm(value: float) -> float:
    return float(value) * 1_000_000.0


def _mm(value: float) -> float:
    return round(value / 1_000_000.0, 4)


def _finding(kind: str, status: str, net: str, message: str, **values) -> dict:
    return {"kind": kind, "status": status, "net": net, "message": message, **values}


def _build_paths(tracks: Iterable[dict], net: str, layer: str) -> list[list[tuple[float, float]]]:
    edges = []
    for track in tracks:
        if track.get("net") != net or track.get("layer") != layer:
            continue
        points = track.get("points", ())
        for start, end in zip(points, points[1:]):
            if tuple(start) != tuple(end):
                edges.append((tuple(start), tuple(end)))
    if not edges:
        return []

    adjacency: dict[tuple[float, float], list[int]] = {}
    for index, (start, end) in enumerate(edges):
        adjacency.setdefault(start, []).append(index)
        adjacency.setdefault(end, []).append(index)

    visited: set[int] = set()
    paths = []

    def walk(start_node: tuple[float, float], first_edge: int) -> list[tuple[float, float]]:
        points = [start_node]
        node = start_node
        edge_id = first_edge
        while edge_id not in visited:
            visited.add(edge_id)
            a, b = edges[edge_id]
            next_node = b if a == node else a
            points.append(next_node)
            if len(adjacency[next_node]) != 2:
                break
            options = [candidate for candidate in adjacency[next_node] if candidate not in visited]
            if not options:
                break
            node, edge_id = next_node, options[0]
        return points

    for node, edge_ids in adjacency.items():
        if len(edge_ids) == 2:
            continue
        for edge_id in edge_ids:
            if edge_id not in visited:
                paths.append(walk(node, edge_id))
    for edge_id, (start, _) in enumerate(edges):
        if edge_id not in visited:
            paths.append(walk(start, edge_id))
    return paths


def _bbox(points: Iterable[tuple[float, float]], margin: float = 0.0) -> tuple[float, float, float, float]:
    values = list(points)
    return (
        min(point[0] for point in values) - margin,
        min(point[1] for point in values) - margin,
        max(point[0] for point in values) + margin,
        max(point[1] for point in values) + margin,
    )


def _bbox_intersects(a: tuple[float, float, float, float], b: tuple[float, float, float, float]) -> bool:
    return not (a[2] < b[0] or b[2] < a[0] or a[3] < b[1] or b[3] < a[1])


def _zone_bbox(zone: dict, polygon: dict) -> tuple[float, float, float, float]:
    return _bbox(polygon.get("outer", ()))


def _reference_features(board: dict, net: str, layer: str, route_box: tuple[float, float, float, float]) -> tuple[list, list, list]:
    zones = []
    for zone in board.get("zones", ()):
        if zone.get("net") != net or zone.get("layer") != layer or not zone.get("filled", False):
            continue
        for polygon in zone.get("polygons", ()):
            if polygon.get("outer") and _bbox_intersects(route_box, _zone_bbox(zone, polygon)):
                zones.append(polygon)

    tracks = []
    for track in board.get("tracks", ()):
        if track.get("net") != net or track.get("layer") != layer:
            continue
        points = track.get("points", ())
        if len(points) >= 2 and _bbox_intersects(route_box, _bbox(points, track.get("width_nm", 0) / 2.0)):
            tracks.append(track)

    vias = []
    for via in board.get("vias", ()):
        if via.get("net") != net or layer not in via.get("layers", ()):
            continue
        radius = via.get("diameter_nm", 0) / 2.0
        x, y = via["position"]
        if _bbox_intersects(route_box, (x - radius, y - radius, x + radius, y + radius)):
            vias.append(via)
    return zones, tracks, vias


def _point_has_reference(point: tuple[float, float], zones: list, tracks: list, vias: list) -> bool:
    if any(point_in_polygon(point, polygon) for polygon in zones):
        return True
    for track in tracks:
        points = track["points"]
        radius = track.get("width_nm", 0) / 2.0
        if any(distance_to_segment(point, start, end) <= radius for start, end in zip(points, points[1:])):
            return True
    for via in vias:
        radius = via.get("diameter_nm", 0) / 2.0
        if hypot(point[0] - via["position"][0], point[1] - via["position"][1]) <= radius:
            return True
    return False


def _corridor_points(point: tuple[float, float], tangent: tuple[float, float], width: float, count: int) -> list[tuple[float, float]]:
    normal = (-tangent[1], tangent[0])
    if count <= 1 or width <= 0:
        return [point]
    return [
        (point[0] + normal[0] * (index / (count - 1) - 0.5) * width,
         point[1] + normal[1] * (index / (count - 1) - 0.5) * width)
        for index in range(count)
    ]


def _not_evaluated_plane(net: str, layer: str, reason: str) -> dict:
    return _finding("REFERENCE_COVERAGE", "NOT_EVALUATED", net, reason, layer=layer)


def _mapping_issue(board: dict, reference_net: str, reference_layer: str) -> str | None:
    if board.get("net_inventory_complete") and reference_net not in board.get("nets", ()):
        available = ", ".join(board.get("nets", ())) or "none"
        return f"Reference net {reference_net!r} is not on this board. Available nets: {available}."
    if board.get("layer_inventory_complete") and reference_layer not in board.get("copper_layers", ()):
        available = ", ".join(board.get("copper_layers", ())) or "none"
        return f"Reference layer {reference_layer!r} is not enabled on this board. Copper layers: {available}."
    return None


def _analyze_path(board: dict, net: str, layer: str, path: list[tuple[float, float]], settings: dict, mapping: dict) -> dict:
    reference_net = mapping.get("net")
    reference_layer = mapping.get("layer")
    if not reference_net or not reference_layer:
        return _not_evaluated_plane(net, layer, "Reference net or layer is not mapped.")
    issue = _mapping_issue(board, reference_net, reference_layer)
    if issue:
        return _not_evaluated_plane(net, layer, issue)
    if not board.get("zone_geometry_available", False):
        return _not_evaluated_plane(net, layer, "KiCad did not provide filled-zone geometry.")
    if any(z.get("net") == reference_net and z.get("layer") == reference_layer for z in board.get("unfilled_zones", ())):
        return _not_evaluated_plane(net, layer, "A reference zone is unfilled. Refill zones in KiCad and run again.")
    if any(z.get("net") == reference_net and z.get("layer") == reference_layer for z in board.get("unsupported_zones", ())):
        return _not_evaluated_plane(net, layer, "A reference zone uses geometry this prototype cannot read.")

    pitch = _mm_to_nm(float(settings.get("sample_pitch_mm", 0.25)))
    corridor = _mm_to_nm(float(settings.get("corridor_width_mm", 0.8)))
    minimum_coverage = float(settings.get("min_coverage", 0.8))
    max_gap = _mm_to_nm(float(settings.get("max_gap_mm", 0.5)))
    sample_count = max(1, int(settings.get("samples_across", 5)))
    if pitch <= 0 or corridor < 0 or not 0.0 <= minimum_coverage <= 1.0 or max_gap < 0:
        return _not_evaluated_plane(net, layer, "Review settings contain an invalid distance or coverage value.")

    route_box = _bbox(path, corridor / 2.0)
    zones, tracks, vias = _reference_features(board, reference_net, reference_layer, route_box)
    total_length = 0.0
    covered_length = 0.0
    current_gap = None
    gaps = []
    for center_distance, cell_length, point, tangent in polyline_cells(path, pitch):
        test_points = _corridor_points(point, tangent, corridor, sample_count)
        ratio = sum(_point_has_reference(p, zones, tracks, vias) for p in test_points) / len(test_points)
        total_length += cell_length
        covered_length += cell_length * ratio
        start_distance = center_distance - cell_length / 2.0
        end_distance = center_distance + cell_length / 2.0
        if ratio < minimum_coverage:
            if current_gap is None:
                current_gap = [start_distance, end_distance]
            else:
                current_gap[1] = end_distance
        elif current_gap is not None:
            gaps.append(current_gap)
            current_gap = None
    if current_gap is not None:
        gaps.append(current_gap)

    longest_gap = max((end - start for start, end in gaps), default=0.0)
    status = "REVIEW" if longest_gap > max_gap else "WITHIN_USER_LIMITS"
    gap_values = [{"start_mm": _mm(start), "end_mm": _mm(end), "length_mm": _mm(end - start)} for start, end in gaps]
    return _finding(
        "REFERENCE_COVERAGE",
        status,
        net,
        "Reference-copper coverage was measured along this route segment chain.",
        layer=layer,
        reference_net=reference_net,
        reference_layer=reference_layer,
        coverage_percent=round(100.0 * covered_length / total_length, 2) if total_length else 0.0,
        longest_gap_mm=_mm(longest_gap),
        maximum_gap_mm=_mm(max_gap),
        sample_pitch_mm=_mm(pitch),
        gaps=gap_values,
        route_length_mm=_mm(total_length),
    )


def _track_touches_via(track: dict, position: list, tolerance: float) -> bool:
    points = track.get("points", ())
    if not points:
        return False
    return any(distance_to_segment(position, start, end) <= tolerance for start, end in zip(points, points[1:]))


def _analyze_transitions(board: dict, net: str, settings: dict, mappings: dict) -> list[dict]:
    findings = []
    signal_tracks = [track for track in board.get("tracks", ()) if track.get("net") == net]
    max_offset = _mm_to_nm(float(settings.get("max_return_via_offset_mm", 1.5)))
    tolerance = _mm_to_nm(float(settings.get("via_match_tolerance_mm", 0.1)))
    if max_offset < 0 or tolerance < 0:
        return [_finding("RETURN_VIA", "NOT_EVALUATED", net, "Via distance settings cannot be negative.")]

    for signal_via in board.get("vias", ()):
        if signal_via.get("net") != net:
            continue
        position = signal_via.get("position", (0, 0))
        touched = {
            track.get("layer")
            for track in signal_tracks
            if _track_touches_via(track, position, tolerance)
            and track.get("layer") in signal_via.get("layers", ())
        }
        for layer_a, layer_b in combinations(sorted(touched), 2):
            mapping_a = mappings.get(layer_a)
            mapping_b = mappings.get(layer_b)
            if not mapping_a or not mapping_b:
                findings.append(_finding("RETURN_VIA", "NOT_EVALUATED", net, "A signal layer at this transition has no reference mapping.", position_mm=[_mm(position[0]), _mm(position[1])], layers=[layer_a, layer_b]))
                continue
            ref_net_a, ref_layer_a = mapping_a.get("net"), mapping_a.get("layer")
            ref_net_b, ref_layer_b = mapping_b.get("net"), mapping_b.get("layer")
            if not all((ref_net_a, ref_layer_a, ref_net_b, ref_layer_b)):
                findings.append(_finding("RETURN_VIA", "NOT_EVALUATED", net, "A reference mapping is incomplete.", position_mm=[_mm(position[0]), _mm(position[1])], layers=[layer_a, layer_b]))
                continue
            mapping_issue = _mapping_issue(board, ref_net_a, ref_layer_a) or _mapping_issue(board, ref_net_b, ref_layer_b)
            if mapping_issue:
                findings.append(_finding("RETURN_VIA", "NOT_EVALUATED", net, mapping_issue, position_mm=[_mm(position[0]), _mm(position[1])], layers=[layer_a, layer_b]))
                continue
            if ref_net_a != ref_net_b:
                findings.append(_finding("RETURN_VIA", "REVIEW", net, "The reference net changes across this signal transition.", position_mm=[_mm(position[0]), _mm(position[1])], layers=[layer_a, layer_b], reference_nets=[ref_net_a, ref_net_b]))
                continue
            if ref_layer_a == ref_layer_b:
                findings.append(_finding("RETURN_VIA", "WITHIN_USER_LIMITS", net, "Both signal layers use the same reference conductor.", position_mm=[_mm(position[0]), _mm(position[1])], layers=[layer_a, layer_b], reference_net=ref_net_a, reference_layers=[ref_layer_a, ref_layer_b], offset_mm=0.0, maximum_offset_mm=_mm(max_offset)))
                continue

            required_layers = {ref_layer_a, ref_layer_b}
            candidates = []
            for reference_via in board.get("vias", ()):
                if reference_via.get("net") != ref_net_a or not required_layers.issubset(set(reference_via.get("layers", ()))):
                    continue
                candidate_position = reference_via.get("position", (0, 0))
                offset = hypot(position[0] - candidate_position[0], position[1] - candidate_position[1])
                candidates.append((offset, candidate_position))
            if not candidates:
                findings.append(_finding("RETURN_VIA", "REVIEW", net, "No via on the mapped reference net connects both reference layers.", position_mm=[_mm(position[0]), _mm(position[1])], layers=[layer_a, layer_b], reference_net=ref_net_a, reference_layers=[ref_layer_a, ref_layer_b], offset_mm=None, maximum_offset_mm=_mm(max_offset)))
                continue
            offset, candidate_position = min(candidates, key=lambda item: item[0])
            status = "WITHIN_USER_LIMITS" if offset <= max_offset else "REVIEW"
            findings.append(_finding("RETURN_VIA", status, net, "Nearest reference via evaluated for this signal transition.", position_mm=[_mm(position[0]), _mm(position[1])], layers=[layer_a, layer_b], reference_net=ref_net_a, reference_layers=[ref_layer_a, ref_layer_b], offset_mm=_mm(offset), maximum_offset_mm=_mm(max_offset), reference_via_position_mm=[_mm(candidate_position[0]), _mm(candidate_position[1])]))
    return findings


def analyze_board(board: dict, config: dict) -> dict:
    findings = []
    configured_nets = config.get("nets", {})
    for key in sorted(set(config) - CONFIG_KEYS):
        findings.append(_finding("CONFIGURATION", "NOT_EVALUATED", "", f"Unknown configuration key {key!r}."))
    if not configured_nets:
        findings.append(_finding("CONFIGURATION", "NOT_EVALUATED", "", "No signal nets are configured."))

    for net, settings in configured_nets.items():
        mappings = settings.get("reference_by_signal_layer", {})
        for key in sorted(set(settings) - SETTING_KEYS):
            findings.append(_finding("CONFIGURATION", "NOT_EVALUATED", net, f"Unknown setting {key!r} for signal net {net!r}."))
        for signal_layer, mapping in mappings.items():
            if not isinstance(mapping, dict):
                findings.append(_finding("CONFIGURATION", "NOT_EVALUATED", net, f"Reference mapping for {signal_layer!r} must be an object."))
                continue
            for key in sorted(set(mapping) - {"net", "layer"}):
                findings.append(_finding("CONFIGURATION", "NOT_EVALUATED", net, f"Unknown reference-mapping key {key!r} for signal layer {signal_layer!r}."))
            if any(not isinstance(mapping.get(key), str) or not mapping.get(key).strip() for key in ("net", "layer")):
                findings.append(_finding("CONFIGURATION", "NOT_EVALUATED", net, f"Reference mapping for {signal_layer!r} needs non-empty 'net' and 'layer' names."))
        net_tracks = [track for track in board.get("tracks", ()) if track.get("net") == net]
        if not net_tracks:
            message = "No routed track segments were found for this signal net."
            if board.get("net_inventory_complete"):
                available = ", ".join(board.get("nets", ())) or "none"
                message += f" Available board nets: {available}."
            findings.append(_finding("ROUTE", "NOT_EVALUATED", net, message))
        layers = sorted({track.get("layer") for track in net_tracks if track.get("layer")})
        if board.get("layer_inventory_complete"):
            for configured_layer in sorted(set(mappings) - set(board.get("copper_layers", ()))):
                findings.append(_finding(
                    "CONFIGURATION",
                    "NOT_EVALUATED",
                    net,
                    f"Configured signal layer {configured_layer!r} is not enabled on this board. Copper layers: {', '.join(board.get('copper_layers', ())) or 'none'}.",
                    layer=configured_layer,
                ))
        for layer in layers:
            mapping = mappings.get(layer)
            for path in _build_paths(net_tracks, net, layer):
                findings.append(_analyze_path(board, net, layer, path, settings, mapping or {}))
        findings.extend(_analyze_transitions(board, net, settings, mappings))

    statuses = {finding["status"] for finding in findings}
    overall = "NOT_EVALUATED" if "NOT_EVALUATED" in statuses else "REVIEW" if "REVIEW" in statuses else "WITHIN_USER_LIMITS"
    result = {
        "board_name": board.get("board_name", "KiCad board"),
        "overall_status": overall,
        "finding_count": len(findings),
        "counts": {status: sum(f["status"] == status for f in findings) for status in ("REVIEW", "WITHIN_USER_LIMITS", "NOT_EVALUATED")},
        "findings": findings,
    }
    if "nets" in board or "copper_layers" in board:
        result["board_inventory"] = {
            "nets": board.get("nets", []),
            "net_inventory_complete": board.get("net_inventory_complete", False),
            "copper_layers": board.get("copper_layers", []),
            "layer_inventory_complete": board.get("layer_inventory_complete", False),
        }
    return result
