"""Return-path geometry review for KiCad PCB designs."""
