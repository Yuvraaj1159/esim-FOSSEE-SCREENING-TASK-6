from __future__ import annotations

from math import acos, atan2, ceil, cos, hypot, pi, sin, sqrt
from typing import Iterator, Sequence

Point = tuple[float, float]


def distance_to_segment(point: Point, start: Point, end: Point) -> float:
    dx = end[0] - start[0]
    dy = end[1] - start[1]
    length_sq = dx * dx + dy * dy
    if length_sq == 0:
        return hypot(point[0] - start[0], point[1] - start[1])
    t = ((point[0] - start[0]) * dx + (point[1] - start[1]) * dy) / length_sq
    t = max(0.0, min(1.0, t))
    nearest = (start[0] + t * dx, start[1] + t * dy)
    return hypot(point[0] - nearest[0], point[1] - nearest[1])


def _on_segment(point: Point, start: Point, end: Point, tolerance: float = 1e-7) -> bool:
    if distance_to_segment(point, start, end) > tolerance:
        return False
    return (
        min(start[0], end[0]) - tolerance <= point[0] <= max(start[0], end[0]) + tolerance
        and min(start[1], end[1]) - tolerance <= point[1] <= max(start[1], end[1]) + tolerance
    )


def point_in_ring(point: Point, ring: Sequence[Point]) -> bool:
    if len(ring) < 3:
        return False
    inside = False
    previous = ring[-1]
    for current in ring:
        if _on_segment(point, previous, current):
            return True
        crosses = (current[1] > point[1]) != (previous[1] > point[1])
        if crosses:
            x_cross = (previous[0] - current[0]) * (point[1] - current[1]) / (previous[1] - current[1]) + current[0]
            if point[0] < x_cross:
                inside = not inside
        previous = current
    return inside


def point_in_polygon(point: Point, polygon: dict) -> bool:
    outer = polygon.get("outer", ())
    if not point_in_ring(point, outer):
        return False
    return not any(point_in_ring(point, hole) for hole in polygon.get("holes", ()))


def arc_to_polyline(start: Point, mid: Point, end: Point, chord_error: float) -> list[Point]:
    if chord_error <= 0:
        raise ValueError("chord_error must be positive")

    ax, ay = start
    bx, by = mid
    cx, cy = end
    determinant = 2.0 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    if abs(determinant) < 1e-9:
        return [start, mid, end]

    a_sq = ax * ax + ay * ay
    b_sq = bx * bx + by * by
    c_sq = cx * cx + cy * cy
    center_x = (a_sq * (by - cy) + b_sq * (cy - ay) + c_sq * (ay - by)) / determinant
    center_y = (a_sq * (cx - bx) + b_sq * (ax - cx) + c_sq * (bx - ax)) / determinant
    radius = hypot(ax - center_x, ay - center_y)
    if radius <= chord_error:
        return [start, mid, end]

    start_angle = atan2(ay - center_y, ax - center_x)
    mid_angle = atan2(by - center_y, bx - center_x)
    end_angle = atan2(cy - center_y, cx - center_x)
    ccw_sweep = (end_angle - start_angle) % (2.0 * pi)
    ccw_mid = (mid_angle - start_angle) % (2.0 * pi)
    sweep = ccw_sweep if ccw_mid <= ccw_sweep + 1e-9 else ccw_sweep - 2.0 * pi

    max_step = 2.0 * acos(max(-1.0, min(1.0, 1.0 - chord_error / radius)))
    count = max(2, int(ceil(abs(sweep) / max(max_step, 1e-6))))
    points = [start]
    for index in range(1, count):
        angle = start_angle + sweep * index / count
        points.append((round(center_x + radius * cos(angle)), round(center_y + radius * sin(angle))))
    points.append(end)
    return points


def polyline_cells(points: Sequence[Point], pitch: float) -> Iterator[tuple[float, float, Point, Point]]:
    if pitch <= 0:
        raise ValueError("pitch must be positive")
    clean: list[Point] = []
    for point in points:
        if not clean or point != clean[-1]:
            clean.append(point)
    if len(clean) < 2:
        return

    segments = []
    total = 0.0
    for start, end in zip(clean, clean[1:]):
        length = hypot(end[0] - start[0], end[1] - start[1])
        if length:
            segments.append((total, total + length, start, end, length))
            total += length
    if total == 0:
        return

    cell_count = int(ceil(total / pitch))
    segment_index = 0
    for index in range(cell_count):
        start_distance = index * pitch
        cell_length = min(pitch, total - start_distance)
        center_distance = start_distance + cell_length / 2.0
        while segment_index + 1 < len(segments) and center_distance > segments[segment_index][1]:
            segment_index += 1
        seg_start, _, start, end, seg_length = segments[segment_index]
        fraction = (center_distance - seg_start) / seg_length
        dx = end[0] - start[0]
        dy = end[1] - start[1]
        point = (start[0] + fraction * dx, start[1] + fraction * dy)
        tangent = (dx / seg_length, dy / seg_length)
        yield center_distance, cell_length, point, tangent
