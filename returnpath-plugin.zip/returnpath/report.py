from __future__ import annotations

import csv
import json
from html import escape
from pathlib import Path

CSV_COLUMNS = (
    "board_name",
    "overall_status",
    "kind",
    "status",
    "net",
    "message",
    "layer",
    "reference_net",
    "reference_layer",
    "coverage_percent",
    "longest_gap_mm",
    "maximum_gap_mm",
    "sample_pitch_mm",
    "route_length_mm",
    "gaps",
    "position_mm",
    "layers",
    "reference_layers",
    "reference_nets",
    "offset_mm",
    "maximum_offset_mm",
    "reference_via_position_mm",
    "note",
)


def render_report(result: dict, note: str = "") -> str:
    rows = []
    for finding in result.get("findings", ()):
        details = []
        for key, label in (
            ("layer", "Signal layer"),
            ("reference_net", "Reference net"),
            ("reference_layer", "Reference layer"),
            ("coverage_percent", "Coverage %"),
            ("longest_gap_mm", "Longest gap mm"),
            ("offset_mm", "Return-via offset mm"),
            ("maximum_gap_mm", "Gap limit mm"),
            ("maximum_offset_mm", "Via limit mm"),
        ):
            if key in finding and finding[key] is not None:
                details.append(f"{label}: {finding[key]}")
        rows.append(
            "<tr>"
            f"<td>{escape(str(finding.get('status', '')))}</td>"
            f"<td>{escape(str(finding.get('kind', '')))}</td>"
            f"<td>{escape(str(finding.get('net', '')))}</td>"
            f"<td>{escape(str(finding.get('message', '')))}<br><small>{escape('; '.join(details))}</small></td>"
            "</tr>"
        )
    if not rows:
        rows.append('<tr><td colspan="4">No findings were generated.</td></tr>')
    note_html = f'<p class="note">{escape(note)}</p>' if note else ""
    counts = result.get("counts", {})
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Return-Path review</title>
<style>
body{{font:15px/1.5 system-ui,sans-serif;color:#20242a;margin:32px auto;padding:0 18px;max-width:1000px}}
h1{{font-size:26px;margin-bottom:4px}}.meta{{color:#606b78}}.note{{background:#f1f5f9;border-left:4px solid #526d88;padding:12px}}
.summary{{display:flex;gap:12px;flex-wrap:wrap;margin:20px 0}}.tile{{border:1px solid #d2d8df;border-radius:8px;padding:12px 16px;min-width:130px}}
.tile strong{{display:block;font-size:20px}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #c8ced5;padding:9px;text-align:left;vertical-align:top}}th{{background:#edf1f5}}small{{color:#586371}}
@media(max-width:650px){{table{{font-size:13px}}th,td{{padding:6px}}}}
</style></head><body>
<h1>Return-Path Continuity Analyzer</h1>
<div class="meta">Board: {escape(str(result.get('board_name', 'KiCad board')))} · Overall status: {escape(str(result.get('overall_status', 'NOT_EVALUATED')))}</div>
{note_html}
<div class="summary"><div class="tile"><strong>{int(counts.get('REVIEW', 0))}</strong>Review</div><div class="tile"><strong>{int(counts.get('WITHIN_USER_LIMITS', 0))}</strong>Within user limits</div><div class="tile"><strong>{int(counts.get('NOT_EVALUATED', 0))}</strong>Not evaluated</div></div>
<table><thead><tr><th>Status</th><th>Check</th><th>Net</th><th>Finding and measurements</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
<p class="meta">Measurements are geometry-based review aids. They are not signal-integrity certification and do not replace KiCad DRC or a field solver.</p>
</body></html>"""


def write_report(path: Path, result: dict, note: str = "") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_report(result, note), encoding="utf-8")
    return path


def write_json_report(path: Path, result: dict, note: str = "") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {**result, "note": note}
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def write_csv_report(path: Path, result: dict, note: str = "") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=CSV_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        for finding in result.get("findings", ()):
            row = {
                "board_name": result.get("board_name", "KiCad board"),
                "overall_status": result.get("overall_status", "NOT_EVALUATED"),
                "note": note,
                **finding,
            }
            for key, value in row.items():
                if isinstance(value, (dict, list)):
                    row[key] = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
            writer.writerow(row)
    return path
